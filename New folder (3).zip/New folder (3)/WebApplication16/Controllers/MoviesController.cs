﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication16.Controllers
{
    public class MoviesController : Controller
    {
        // GET: Movies
        public ActionResult Index()
        {

            MoviesEntities db = new MoviesEntities();
            return View(from Movies_table1 in db.Movies_table1.Take(10)
                        select Movies_table1);
        }
    }
}